package org.ldv.sushi.apisushi.repository

import org.ldv.sushi.apisushi.domain.Box
import org.springframework.data.repository.CrudRepository

interface BoxRepository : CrudRepository<Box, Long> {

}
